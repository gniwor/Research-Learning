# Documentation links

* [libprimecount](libprimecount.md)
* [primecount-backup](https://github.com/kimwalisch/primecount/tree/backup3)
* [primecount-MPI](primecount-MPI.md)
* [BUILD.md](BUILD.md)
* [RELEASE.md](RELEASE.md)
* [Records.md](Records.md)
* [References.md](References.md)
* [Credits.md](Credits.md)
