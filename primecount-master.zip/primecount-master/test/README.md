# primecount testing

Run the commands below from the root primecount directory.

```bash
cmake -DBUILD_TESTS=ON .
make -j
make test
```
