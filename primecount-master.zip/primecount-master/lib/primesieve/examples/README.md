libprimesieve examples
======================

This directory contains C/C++ example programs that show how to
generate primes using libprimesieve.

Build instructions
==================

Run the commands below from the root primesieve directory.

```sh
cmake -DBUILD_EXAMPLES=ON .
make -j
```
